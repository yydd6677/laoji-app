"""
离线模式2 — VAD切分 + 声纹识别 + top-5投票合并 + ASR转录。

处理流程：
  整段音频
    ↓
  [Step0] 去噪（RNNoise）
    ↓
  [Step1] VAD 切分 → 每个语音片段（全局声纹突变辅助检测说话人变化）
    ↓
  [Step2] 声纹识别 → 每个片段与注册声纹库逐一打分 → 标注说话人（top-1 + top-5 + embedding）
    ↓
  [Step3] top-5投票合并 → 余弦相似度>=0.75 ∩ top-5有交集 ∩ gap<5s → 合并音频，投票决定说话人
    ↓
  [Step4] ASR 转录 → 对合并后的完整片段独立转录（+ 无意义片段过滤）
    ↓
  [Step5] 文本拼接 → speaker_id 相等的相邻片段拼接文本
    ↓
  TurnSegment[]
"""

import asyncio
import copy
import time
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Callable, Any, Tuple

import numpy as np
import torch

from app.asr.model_manager import get_model_manager, SpeakerEmbeddingExtractor
from app.asr.enhanced_engine import EnhancedRecognitionEngine
from app.services.speaker_db_service import get_speaker_db, bytes_to_ndarray

# ASR 后置过滤：无意义语气词/叹词集合
_MEANINGLESS_PATTERNS: set = {
    '嗯', '啊', '呃', '哦', '噢', '呀', '哈', '嗯嗯', '啊啊',
    '哦哦', '噢噢', '嗯嗯嗯', '啊啊啊啊', '嗯啊', '啊嗯', '嗯嗯嗯嗯',
}


@dataclass
class SpeechSegment:
    """
    VAD 切分出的语音片段。

    引用设计：所有子片段共享原始音频 buffer（audio_ref），
    合并时只改偏移量（audio_start/audio_end），永不复制音频数组。
    """
    start_sample: int          # 片段在原音频中的绝对起始位置
    end_sample: int            # 片段在原音频中的绝对结束位置
    audio_ref: np.ndarray      # 指向原始完整音频 buffer 的引用（永不复制）
    audio_start: int           # 在 audio_ref 中的相对起始位置
    audio_end: int             # 在 audio_ref 中的相对结束位置

    @property
    def audio(self) -> np.ndarray:
        """返回该片段对应的音频切片（lazy view，不复制 buffer）"""
        return self.audio_ref[self.audio_start:self.audio_end]

    @property
    def start_ms(self) -> int:
        return int(self.start_sample / 16000 * 1000)

    @property
    def end_ms(self) -> int:
        return int(self.end_sample / 16000 * 1000)

    @property
    def duration_ms(self) -> int:
        return self.end_ms - self.start_ms


@dataclass
class TurnSegment:
    """Turn 级转写片段"""
    speaker_id: Optional[str] = None
    speaker_name: Optional[str] = None
    text: str = ""
    words: List[Any] = field(default_factory=list)
    start_ms: int = 0
    end_ms: int = 0
    confidence: float = 0.0
    top3_ids: List[str] = field(default_factory=list)  # top-3说话人ID，用于跨片段合并判断
    merged_from: int = 1  # 记录该片段由多少个子片段合并而来（用于调试和溯源）


@dataclass
class ProcessingResult:
    """处理结果"""
    meeting_id: str
    turns: List[TurnSegment]
    speakers: Dict[str, Dict]
    summary: Optional[Dict]
    processing_time_ms: float


class OfflinePipeline2:
    """离线模式2：VAD切分 + 声纹识别 + ASR转录 + 时间对齐"""

    def __init__(
        self,
        meeting_id: str,
        sample_rate: int = 16000,
        language: str = "zh",
        on_progress: Optional[Callable[[str, float], None]] = None,
    ):
        self.meeting_id = meeting_id
        self.sample_rate = sample_rate
        self.language = language
        self._report_progress = on_progress or (lambda s, p: None)

        self._model_manager = None
        self._enhanced_engine = None
        self._vad_model = None
        self._vad_sample_rate = 16000
        self._asr_model = None
        self._punc_model = None

        # 说话人姓名映射 (speaker_id -> name)
        self._speaker_names: Dict[str, str] = {}

        # 注册声纹库 (speaker_id -> embedding)
        self._registered_embeddings: Dict[str, np.ndarray] = {}

    # ================================================================
    # 公共 API
    # ================================================================
    # 缓存辅助：统一量化到 8000 样本（500ms @ 16kHz）粒度
    # 缓存 key：用精确的 (audio_start, audio_end)，不量化
    # 每个采样区间独立提取 embedding，不同区间绝不混淆
    @staticmethod
    def _emb_key(audio_start: int, audio_end: int) -> Tuple[int, int]:
        return (audio_start, audio_end)

    def _get_cached_emb(
        self, audio_start: int, audio_end: int,
        emb_cache: Dict[Tuple[int, int], np.ndarray],
        audio_ref: np.ndarray, extractor
    ) -> np.ndarray:
        """从缓存读取 embedding；若缓存未命中则提取并存入缓存"""
        if audio_start >= audio_end:
            return np.zeros(192, dtype=np.float32)
        key = self._emb_key(audio_start, audio_end)
        if key in emb_cache:
            return emb_cache[key]
        audio = audio_ref[key[0]:key[1]]
        if len(audio) < 400:  # CAM++ Kaldi 要求至少 > 2 帧（约400样本@16kHz）
            return np.zeros(192, dtype=np.float32)
        emb = extractor.extract(audio)
        if emb is None:
            emb = np.zeros(192, dtype=np.float32)
        emb = emb / (np.linalg.norm(emb) + 1e-8)
        emb_cache[key] = emb
        return emb

    async def process(self, audio_data: np.ndarray) -> ProcessingResult:
        """处理音频文件"""
        start_time = time.time()

        print(f"[Pipeline2] ═══════════════════════════════════════════════", flush=True)
        print(f"[Pipeline2] 启动，会议ID: {self.meeting_id}", flush=True)
        print(f"[Pipeline2] 音频时长: {len(audio_data) / self.sample_rate:.1f}s", flush=True)
        print(f"[Pipeline2] ═══════════════════════════════════════════════", flush=True)

        self._report_progress("初始化", 0.0)
        await self._initialize()
        self._denoiser.reset()

        # Step 0: 去噪
        self._report_progress("去噪", 0.0)
        audio_data = self._denoiser.denoise(audio_data, sample_rate=self.sample_rate)
        print(f"[Pipeline2] 去噪完成", flush=True)

        # Step 1: VAD 切分
        self._report_progress("VAD切分", 0.0)
        segments = self._vad_segment(audio_data)
        print(f"[Pipeline2] VAD 切分完成: {len(segments)} 个片段", flush=True)

        # 共享 embedding 缓存：同一音频区间只提取一次（避免两个分段函数重复调用 CAM++）
        emb_cache: Dict[Tuple[int, int], np.ndarray] = {}

        # Step 2: 声纹识别
        self._report_progress("声纹识别", 0.0)
        print(f"[Pipeline2] 开始声纹突变分段 + CAM++ 推理（{len(segments)} 段）...", flush=True)
        labeled = self._identify_speakers(segments, emb_cache)
        print(f"[Pipeline2] 声纹识别完成: {len(labeled)} 个子片段", flush=True)

        # Step 3: 基于 top-5投票+余弦相似度合并相邻子片段
        merged = self._merge_speech_segments(labeled)
        print(f"[Pipeline2] top-5投票合并后: {len(merged)} 个合并片段", flush=True)

        # Step 4: ASR 转录（基于合并后的完整片段）
        self._report_progress("ASR转录", 0.0)
        print(f"[Pipeline2] 开始 ASR 转录（{len(merged)} 片段）...", flush=True)
        transcribed = await self._transcribe_segments(merged)
        print(f"[Pipeline2] ASR 转录完成: {len(transcribed)} 个片段", flush=True)

        # Step 5: 组装 turns（纯文本拼接，投票合并已在上一步完成）
        turns = self._build_turns(transcribed)
        speakers = self._collect_speakers(turns)

        # Step 6: 生成摘要
        self._report_progress("生成摘要", 0.0)
        summary = await self._generate_summary(turns)
        self._report_progress("生成摘要", 1.0)

        processing_time_ms = (time.time() - start_time) * 1000

        print(f"[Pipeline2] ═══════════════════════════════════════════════", flush=True)
        print(f"[Pipeline2] 完成: {len(turns)} turns, {len(speakers)} speakers, "
              f"耗时 {processing_time_ms:.0f}ms", flush=True)
        print(f"[Pipeline2] ═══════════════════════════════════════════════", flush=True)

        self._report_progress("完成", 1.0)

        return ProcessingResult(
            meeting_id=self.meeting_id,
            turns=turns,
            speakers=speakers,
            summary=summary,
            processing_time_ms=processing_time_ms,
        )

    # ================================================================
    # 初始化
    # ================================================================

    async def _initialize(self):
        """加载模型和声纹库"""
        self._model_manager = get_model_manager()
        if not self._model_manager.is_initialized():
            print("[Pipeline2] 模型未初始化，等待...", flush=True)
            await self._model_manager.initialize()
        print("[Pipeline2] 模型就绪", flush=True)

        # 加载 VAD
        self._vad_model = self._model_manager.get_vad_model()
        self._vad_sample_rate = self._model_manager.vad_model_samplerate

        # 加载 ASR
        self._asr_model = self._model_manager.get_asr_model()
        if self._asr_model is None:
            raise RuntimeError("ASR 模型未加载")

        self._punc_model = self._model_manager.get_punc_model()

        # 加载声纹引擎
        camp_model = self._model_manager.get_camp_model()
        if camp_model is not None:
            extractor = SpeakerEmbeddingExtractor(camp_model, device=self._model_manager.device)
            self._enhanced_engine = EnhancedRecognitionEngine(extractor)
            print("[Pipeline2] 声纹引擎就绪", flush=True)
        else:
            raise RuntimeError("CAM++ 模型未加载")

        # 加载去噪器（RNNoise）
        from app.asr.audio_denoiser import get_denoiser
        self._denoiser = get_denoiser(backend="rnnoise")
        print("[Pipeline2] 去噪器就绪（RNNoise）", flush=True)

        # 加载说话人声纹库
        speaker_db = get_speaker_db()
        db_speakers = speaker_db.load_all(active_only=True)
        print(f"[Pipeline2] 加载 {len(db_speakers)} 位注册说话人", flush=True)

        for sp in db_speakers:
            sid = sp.get("speaker_id")
            name = sp.get("name")
            raw_emb = sp.get("embedding")

            if sid and name:
                self._speaker_names[sid] = name

            if sid and raw_emb is not None:
                try:
                    if isinstance(raw_emb, bytes):
                        emb = bytes_to_ndarray(raw_emb)
                    elif isinstance(raw_emb, np.ndarray):
                        emb = raw_emb
                    else:
                        emb = np.frombuffer(bytes(raw_emb), dtype=np.float32)
                    emb = emb.astype(np.float32)
                    self._registered_embeddings[sid] = emb
                    self._enhanced_engine.register_embedding(sid, emb, name=name)
                except Exception as e:
                    print(f"[Pipeline2] 加载声纹 {sid} 失败: {e}", flush=True)

        print(f"[Pipeline2] 注册声纹库: {len(self._registered_embeddings)} 人", flush=True)

    # ================================================================
    # Step 1: VAD 切分
    # ================================================================

    def _vad_segment(self, audio: np.ndarray) -> List[SpeechSegment]:
        """
        使用 Silero VAD 批量推理标注语音区域，再用声纹突变做二次分段。
        不依赖静音分段，保证不丢音频。
        """
        print(f"[Pipeline2-VAD] 开始切分，音频长度: {len(audio)} samples ({len(audio)/16000:.1f}s)", flush=True)

        vad_model = self._vad_model
        sr = self.sample_rate

        if vad_model is None:
            print("[Pipeline2-VAD] VAD 模型未加载", flush=True)
            return []

        # 转换为 int16
        if audio.max() <= 1.0:
            audio_int = (audio * 32767).astype(np.int16)
        else:
            audio_int = audio.astype(np.int16)

        # 遍历参数
        WINDOW_SIZE = 512    # 32ms（Silero最小输入）
        HOP_SIZE = 512       # 32ms
        THRESHOLD = 0.30     # 与实时模式一致：0.30
        MIN_SEG_SAMPLES = int(1.5 * sr)   # 1500ms，最短语音片段（实时模式 MIN_SPEECH_DURATION_MS）
        MAX_GAP_SAMPLES = int(0.5 * sr)   # 500ms，静音间隙超过此值则切分（实时模式 MIN_SILENCE_DURATION_MS）
        MIN_WINDOW_ENERGY = 0.005

        device = next(vad_model.parameters(), torch.zeros(0, device='cpu')).device

        # Step 1: 一次性批量 VAD 推理（替代逐窗口循环，提速 ~50 倍）
        # 第一遍：计算全局噪声底噪（用于能量阈值）
        all_energies: List[float] = []
        for i in range(0, len(audio_int) - WINDOW_SIZE + 1, HOP_SIZE):
            chunk = audio_int[i:i + WINDOW_SIZE]
            rms = float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2))) / 32767.0
            all_energies.append(rms)

        sorted_energies = sorted(all_energies)
        noise_idx = max(0, int(len(sorted_energies) * 0.10))
        noise_floor = sorted_energies[noise_idx]
        energy_threshold = max(MIN_WINDOW_ENERGY, noise_floor * 5.0, noise_floor + 0.005)
        print(f"[Pipeline2-VAD] 噪声底噪: {noise_floor:.5f}, 能量阈值: {energy_threshold:.5f}", flush=True)

        # 第二遍：批量 VAD + 能量过滤
        # 分批处理，防止一次性分配过多内存
        BATCH_SIZE = 2048
        speech_windows: List[int] = []

        for batch_start in range(0, len(audio_int) - WINDOW_SIZE + 1, HOP_SIZE * BATCH_SIZE):
            batch_indices = list(range(
                batch_start,
                min(batch_start + HOP_SIZE * BATCH_SIZE, len(audio_int) - WINDOW_SIZE + 1),
                HOP_SIZE
            ))
            if not batch_indices:
                break

            # 收集当前批次音频
            batch_chunks = []
            batch_energies = []
            for idx in batch_indices:
                chunk = audio_int[idx:idx + WINDOW_SIZE]
                batch_chunks.append(chunk)
                rms = float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2))) / 32767.0
                batch_energies.append(rms)

            # 逐条推理：Silero VAD 内部 unsqueeze(0)，不支持批次输入，batch 仅用于控制循环规模
            batch_probs = []
            for chunk in batch_chunks:
                tensor = torch.from_numpy(chunk.astype(np.float32) / 32767.0).unsqueeze(0).to(device)
                with torch.no_grad():
                    prob = vad_model(tensor, sr).item()
                batch_probs.append(prob)

            for idx, (prob, rms) in zip(batch_indices, zip(batch_probs, batch_energies)):
                if prob > THRESHOLD and rms >= energy_threshold:
                    speech_windows.append(idx)

        print(f"[Pipeline2-VAD] 语音窗口: {len(speech_windows)} 个", flush=True)

        # Step 2: 合并相邻语音区域（gap < MAX_GAP 则视为同一段）
        if not speech_windows:
            print("[Pipeline2-VAD] 未检测到语音", flush=True)
            return []

        speech_ranges: List[Tuple[int, int]] = []
        cur_start = speech_windows[0]
        cur_end = speech_windows[0] + WINDOW_SIZE

        for pos in speech_windows[1:]:
            if pos - cur_end <= MAX_GAP_SAMPLES:
                # gap 较小，合并
                cur_end = pos + WINDOW_SIZE
            else:
                # gap 较大，切分
                speech_ranges.append((cur_start, cur_end))
                cur_start = pos
                cur_end = pos + WINDOW_SIZE

        speech_ranges.append((cur_start, cur_end))

        # 兜底：将 < 200ms 的极短区域合并到前一个区域
        # VAD 可能把噪声误检为语音，单独一个小窗口，前后 gap > 500ms，
        # 这些碎片如果直接输出，CAM++ 无法提取有效 embedding
        MIN_TINY_SAMPLES = int(0.2 * sr)  # 200ms
        i = 1
        while i < len(speech_ranges):
            s_start, s_end = speech_ranges[i]
            if s_end - s_start < MIN_TINY_SAMPLES:
                # 合并到前一个
                p_start, p_end = speech_ranges[i - 1]
                speech_ranges[i - 1] = (p_start, s_end)
                speech_ranges.pop(i)
                # 不 i += 1，继续检查同一个位置（可能被合并后仍然很短）
            else:
                i += 1

        print(f"[Pipeline2-VAD] 语音区域合并后: {len(speech_ranges)} 段", flush=True)

        # Step 3: 对每个区域（≥1500ms）做声纹突变二次分段
        # 传入 audio_ref，让所有子片段共享原始 buffer（合并时避免复制）
        all_segments: List[SpeechSegment] = []
        total_ranges = len(speech_ranges)
        for idx, (start, end) in enumerate(speech_ranges):
            if idx % 20 == 0:
                print(f"[Pipeline2-VAD] 声纹突变分段: {idx}/{total_ranges}", flush=True)
            if end - start < MIN_SEG_SAMPLES:
                # 片段太短，直接保留（引用原始 buffer）
                all_segments.append(SpeechSegment(
                    start_sample=start, end_sample=end, audio_ref=audio,
                    audio_start=start, audio_end=end,
                ))
                continue

            # 声纹突变二次分段（传入切片 + 原始 buffer 引用）
            seg_audio = audio[start:end]
            sub_segs = self._split_by_speaker_change(
                seg_audio, seg_start=start, audio_ref=audio
            )
            all_segments.extend(sub_segs)

        print(f"[Pipeline2-VAD] 声纹突变分段后: {len(all_segments)} 个片段", flush=True)
        for i, seg in enumerate(all_segments):
            print(f"  片段{i+1}: [{seg.start_ms}-{seg.end_ms}ms] ({seg.duration_ms}ms)", flush=True)

        # 最终兜底：确保所有输出片段长度 >= 200ms
        MIN_FINAL_MS = 200  # 200ms
        for _pass in range(2):  # 最多两遍
            changed = False
            i = 0
            while i < len(all_segments):
                seg = all_segments[i]
                if seg.duration_ms < MIN_FINAL_MS:
                    if i > 0:
                        prev = all_segments[i - 1]
                        # 合并元数据：前一个 end 扩展到当前 end，audio_ref 延续前一个
                        all_segments[i - 1] = SpeechSegment(
                            start_sample=prev.start_sample,
                            end_sample=seg.end_sample,
                            audio_ref=prev.audio_ref,
                            audio_start=prev.audio_start,
                            audio_end=seg.audio_end,
                        )
                        all_segments.pop(i)
                        changed = True
                    elif i + 1 < len(all_segments):
                        nxt = all_segments[i + 1]
                        # 合并到下一个：统一用 seg 的 audio_ref（seg 是主片段，i=0 时 prev 不存在）
                        all_segments[i] = SpeechSegment(
                            start_sample=seg.start_sample,
                            end_sample=nxt.end_sample,
                            audio_ref=seg.audio_ref,
                            audio_start=seg.audio_start,
                            audio_end=nxt.audio_end,
                        )
                        all_segments.pop(i + 1)
                        changed = True
                    else:
                        i += 1
                else:
                    i += 1
            if not changed:
                break

        print(f"[Pipeline2-VAD] 最小片段过滤后: {len(all_segments)} 个片段", flush=True)
        for i, seg in enumerate(all_segments):
            print(f"  片段{i+1}: [{seg.start_ms}-{seg.end_ms}ms] ({seg.duration_ms}ms)", flush=True)

        return all_segments

    def _split_by_speaker_change(
        self, audio: np.ndarray, seg_start: int = 0, audio_ref: np.ndarray = None,
        emb_cache: Dict[Tuple[int, int], np.ndarray] = None
    ) -> List[SpeechSegment]:
        """
        对一个语音区域用声纹突变做二次分段。
        audio_ref: 原始音频 buffer，所有子片段共享此引用。
        emb_cache: embedding 缓存，同一音频区间只提取一次。
        """
        if emb_cache is None:
            emb_cache = {}
        if audio_ref is None:
            audio_ref = audio
        extractor = self._enhanced_engine.extractor
        sr = self.sample_rate

        # 500ms 窗口，50% hop（window_samples=8000 @ 16kHz）
        # 相比原来的 100ms/50hop，提速 5 倍，内存多 5 倍但可接受
        window_ms = 500
        window_samples = int(window_ms * sr / 1000)   # 8000
        hop_samples = window_samples // 2             # 4000
        n_windows = max(1, (len(audio) - window_samples) // hop_samples + 1)

        if len(audio) < sr * 1.5:
            return [SpeechSegment(start_sample=seg_start, end_sample=seg_start + len(audio),
                                 audio_ref=audio_ref, audio_start=seg_start,
                                 audio_end=seg_start + len(audio))]

        if n_windows < 4:
            return [SpeechSegment(
                start_sample=seg_start, end_sample=seg_start + len(audio),
                audio_ref=audio_ref, audio_start=seg_start, audio_end=seg_start + len(audio))]

        # 提取每个窗口的 embedding
        window_embs: List[np.ndarray] = []
        window_times_ms: List[int] = []

        for w in range(n_windows):
            w_start = w * hop_samples
            w_end = min(w_start + window_samples, len(audio))
            w_audio = audio[w_start:w_end]
            if len(w_audio) < window_samples * 0.5:
                continue
            try:
                chunk_rms = float(np.sqrt(np.mean(w_audio ** 2)))
                if chunk_rms < 0.005:
                    continue
                w_abs_start = seg_start + w_start
                w_abs_end = seg_start + w_end
                emb = self._get_cached_emb(w_abs_start, w_abs_end, emb_cache, audio_ref, extractor)
                if emb is not None and np.linalg.norm(emb) > 1e-6:
                    window_embs.append(emb)
                    window_times_ms.append(int(seg_start + w_start * 1000 / sr))
            except Exception:
                pass

        if len(window_embs) < 4:
            return [SpeechSegment(
                start_sample=seg_start, end_sample=seg_start + len(audio),
                audio_ref=audio_ref, audio_start=seg_start, audio_end=seg_start + len(audio))]

        # 计算相邻窗口的声纹距离
        distances = np.array([
            1.0 - float(np.clip(np.dot(window_embs[j], window_embs[j + 1]), -1.0, 1.0))
            for j in range(len(window_embs) - 1)
        ])

        # 找变化点
        hard_threshold = 0.35
        soft_threshold = 0.25
        force_cuts = [i for i, d in enumerate(distances) if d > hard_threshold]
        cp_indices = self._find_changepoints_binaryseg(distances, threshold=soft_threshold)
        all_cp = sorted(set(cp_indices) | set(force_cuts))

        if not all_cp:
            return [SpeechSegment(
                start_sample=seg_start, end_sample=seg_start + len(audio),
                audio_ref=audio_ref, audio_start=seg_start, audio_end=seg_start + len(audio))]

        # 构建切分边界
        all_cuts = [0] + [i + 1 for i in all_cp] + [n_windows]

        # 过滤过密切分点（相邻 < 3 窗口 ~300ms）
        MIN_CUT_GAP = 3
        filtered = [all_cuts[0]]
        for c in all_cuts[1:-1]:
            if c - filtered[-1] >= MIN_CUT_GAP:
                filtered.append(c)
        filtered.append(all_cuts[-1])
        all_cuts = filtered

        # 构建所有子片段（引用原 buffer，不复制音频）
        subs: List[SpeechSegment] = []
        for k in range(len(all_cuts) - 1):
            s = all_cuts[k] * hop_samples
            e = min(all_cuts[k + 1] * hop_samples, len(audio))
            if e > s:
                subs.append(SpeechSegment(
                    start_sample=seg_start + s,
                    end_sample=seg_start + e,
                    audio_ref=audio_ref,
                    audio_start=seg_start + s,
                    audio_end=seg_start + e,
                ))

        # 合并过短片段（只更新偏移量，不复制音频）
        MIN_SUB_SAMPLES = int(0.2 * sr)
        result: List[SpeechSegment] = []
        i = 0
        while i < len(subs):
            cur = subs[i]
            cur_len = cur.audio_end - cur.audio_start
            if cur_len >= MIN_SUB_SAMPLES:
                result.append(cur)
                i += 1
            else:
                if result:
                    p = result[-1]
                    # 合并：前一个 end 扩展到当前 end，audio_ref 延续前一个
                    merged = SpeechSegment(
                        start_sample=p.start_sample,
                        end_sample=cur.end_sample,
                        audio_ref=p.audio_ref,
                        audio_start=p.audio_start,
                        audio_end=cur.audio_end,
                    )
                    result[-1] = merged
                    i += 1
                else:
                    # 第一个片段就太短：往后找足够长的来扩展
                    merged = cur
                    j = i + 1
                    while j < len(subs) and (merged.audio_end - merged.audio_start) < MIN_SUB_SAMPLES:
                        nxt = subs[j]
                        merged = SpeechSegment(
                            start_sample=merged.start_sample,
                            end_sample=nxt.end_sample,
                            audio_ref=merged.audio_ref,
                            audio_start=merged.audio_start,
                            audio_end=nxt.audio_end,
                        )
                        j += 1
                    result.append(merged)
                    i = j

        return result

    def _find_changepoints_binaryseg(self, distances: np.ndarray, threshold: float = 0.15) -> List[int]:
        """Binary segmentation 找变化点"""
        n = len(distances)
        if n < 4:
            return []

        window = 3
        padded = np.concatenate([[0.0] * (window // 2), distances, [0.0] * (window // 2)])
        local_mean = np.convolve(padded, np.ones(window) / window, mode='valid')

        significant = np.where(
            (distances > threshold) & (distances > local_mean * 1.2)
        )[0]

        if len(significant) == 0:
            return []

        # 聚类相邻点，保留最大值
        filtered: List[int] = []
        cluster: List[int] = []
        for idx in significant:
            if cluster and idx - cluster[-1] <= 2:
                if distances[idx] > distances[cluster[-1]]:
                    cluster[-1] = idx
            else:
                if cluster:
                    filtered.append(max(cluster, key=lambda i: distances[i]))
                cluster = [idx]
        if cluster:
            filtered.append(max(cluster, key=lambda i: distances[i]))

        return filtered

    # ================================================================
    # Step 2: 声纹识别
    # ================================================================

    def _identify_speakers(
        self, segments: List[SpeechSegment],
        emb_cache: Dict[Tuple[int, int], np.ndarray]
    ) -> List[Tuple[SpeechSegment, str, float, List[str], np.ndarray]]:
        """
        对每个片段做声纹识别（返回top-1 + top-5 + embedding），不做合并。
        返回 (片段, speaker_id, score, top5_ids, embedding)。
        合并逻辑在 _merge_speech_segments 中处理。
        """
        results: List[Tuple[SpeechSegment, str, float, List[str], np.ndarray]] = []

        for i, seg in enumerate(segments):
            if i % 10 == 0:
                print(f"[Pipeline2-声纹] 处理 VAD 片段 {i+1}/{len(segments)}...", flush=True)
            sub_segs = self._split_by_speaker_within_segment(seg, emb_cache)
            for sub in sub_segs:
                top1_id, top1_score, top5_ids, emb = self._match_speaker(sub, emb_cache)
                results.append((sub, top1_id, top1_score, top5_ids, emb))

        return results

    def _merge_speech_segments(
        self,
        labeled: List[Tuple[SpeechSegment, str, float, List[str], np.ndarray]],
    ) -> List[Tuple[SpeechSegment, str, float, List[str], np.ndarray, int]]:
        """
        基于 top-5 投票 + 余弦相似度合并相邻子片段。

        合并条件（必须同时满足）：
          1. gap < 5s
          2. 两片段 top-5 有交集（存在共同候选说话人）
          3. 两片段 embedding 余弦相似度 >= SIM_THRESHOLD（0.75）

        合并后说话人由 top-5 投票决定：统计所有参与片段的 top-5 列表中出现次数最多的说话人。
        返回 (片段, speaker_id, score, top5_ids, embedding, merged_from)。
        """
        if not labeled:
            return []

        SIM_THRESHOLD = 0.50  # 从0.75放宽至0.50，尽量合并同一说话人的相邻片段

        # 第一个片段
        first_audio, first_sid, first_score, first_top5, first_emb = labeled[0]
        result: List[Tuple[SpeechSegment, str, float, List[str], np.ndarray, int]] = [
            (first_audio, first_sid, first_score, first_top5, first_emb, 1)
        ]

        for cur in labeled[1:]:
            cur_audio, cur_sid, cur_score, cur_top5, cur_emb = cur

            while True:
                prev_audio, prev_sid, prev_score, prev_top5, prev_emb, prev_merged = result[-1]
                gap_ms = cur_audio.start_ms - prev_audio.end_ms

                if gap_ms >= 5000:
                    result.append((cur_audio, cur_sid, cur_score, cur_top5, cur_emb, 1))
                    break

                # 条件1: top-5 有交集
                if not (set(prev_top5) & set(cur_top5)):
                    result.append((cur_audio, cur_sid, cur_score, cur_top5, cur_emb, 1))
                    break

                # 条件2: 余弦相似度足够
                p = prev_emb / (np.linalg.norm(prev_emb) + 1e-8)
                c = cur_emb / (np.linalg.norm(cur_emb) + 1e-8)
                similarity = float(np.dot(p, c))
                if similarity < SIM_THRESHOLD:
                    result.append((cur_audio, cur_sid, cur_score, cur_top5, cur_emb, 1))
                    break

                # --- 通过全部检查，执行合并 ---
                # 1) 合并元数据：只扩展前一个片段的 end 偏移，引用同一个 audio_ref（无复制）
                merged_audio_seg = SpeechSegment(
                    start_sample=prev_audio.start_sample,
                    end_sample=cur_audio.end_sample,
                    audio_ref=prev_audio.audio_ref,
                    audio_start=prev_audio.audio_start,
                    audio_end=cur_audio.audio_end,
                )

                # 2) top-5 投票决定最终说话人
                from collections import Counter
                vote_pool = prev_top5 + cur_top5
                voted_sid, _ = Counter(vote_pool).most_common(1)[0]
                voted_top5 = list(dict.fromkeys(vote_pool))  # 去重保持顺序

                # 3) 投票得分：取该说话人在两个片段中的得分，取最高值
                scored_pool = []
                for top5_list in [prev_top5, cur_top5]:
                    for rank, sid in enumerate(top5_list):
                        if sid == voted_sid:
                            # 排名越前权重越高，用 (5 - rank) 估算相对得分
                            scored_pool.append(1.0 - rank * 0.1)
                voted_score = max(scored_pool) if scored_pool else 0.5

                result[-1] = (
                    merged_audio_seg, voted_sid, voted_score, voted_top5,
                    prev_emb, prev_merged + 1,
                )
                # 更新 cur，继续尝试向前合并
                cur_audio = merged_audio_seg
                cur_emb = prev_emb
                cur_sid = voted_sid
                cur_score = voted_score
                cur_top5 = voted_top5

        return result

    def _split_by_speaker_within_segment(
        self, seg: SpeechSegment,
        emb_cache: Dict[Tuple[int, int], np.ndarray]
    ) -> List[SpeechSegment]:
        """
        对一个片段按说话人变化点切分。
        提取多个 embedding，如果相邻 embedding 距离 > 阈值则切分。
        emb_cache: embedding 缓存，同一音频区间只提取一次。
        """
        if seg.duration_ms < 1000:
            return [seg]

        extractor = self._enhanced_engine.extractor
        sr = self.sample_rate

        # 间隔1.5s提取一次embedding（与实时模式一致）
        EMB_INTERVAL_MS = 1500
        EMB_INTERVAL = int(EMB_INTERVAL_MS * sr / 1000)

        emb_positions_abs: List[int] = []
        emb_list: List[np.ndarray] = []

        pos_rel = 0  # 相对位置（seg.audio 内的偏移）
        audio_len = seg.audio_end - seg.audio_start
        while pos_rel < audio_len:
            remaining = audio_len - pos_rel
            chunk_size = min(EMB_INTERVAL, remaining)
            if chunk_size < EMB_INTERVAL * 0.5:
                break
            # 用绝对位置从 audio_ref 截取
            chunk_abs_start = seg.audio_start + pos_rel
            chunk_abs_end = chunk_abs_start + chunk_size
            emb_audio = seg.audio_ref[chunk_abs_start:chunk_abs_end]
            try:
                chunk_rms = float(np.sqrt(np.mean(emb_audio ** 2)))
                if chunk_rms < 0.005:
                    pos_rel += EMB_INTERVAL
                    continue
                emb = self._get_cached_emb(chunk_abs_start, chunk_abs_end, emb_cache,
                                          seg.audio_ref, extractor)
                if emb is not None and np.linalg.norm(emb) > 1e-6:
                    emb_list.append(emb)
                    emb_positions_abs.append(chunk_abs_start)  # 绝对位置
            except Exception:
                pass
            pos_rel += EMB_INTERVAL

        # 如果提取不到2个以上embedding，直接返回原片段
        if len(emb_list) < 2:
            return [seg]

        # 检测相邻embedding距离，找变化点
        CHANGE_THRESHOLD = 0.35
        cut_points_abs: List[int] = []
        for j in range(len(emb_list) - 1):
            d = 1.0 - float(np.clip(np.dot(emb_list[j], emb_list[j + 1]), -1.0, 1.0))
            if d > CHANGE_THRESHOLD:
                # 说话人变化，取两者的中间点作为切分位置
                cut_pos = (emb_positions_abs[j] + emb_positions_abs[j + 1]) // 2
                cut_points_abs.append(cut_pos)

        if not cut_points_abs:
            return [seg]

        # 按变化点切分（使用绝对位置构造子片段）
        sub_segs: List[SpeechSegment] = []
        prev_abs = seg.audio_start
        for cp_abs in cut_points_abs:
            if cp_abs > prev_abs:
                sub_segs.append(SpeechSegment(
                    start_sample=prev_abs,
                    end_sample=cp_abs,
                    audio_ref=seg.audio_ref,
                    audio_start=prev_abs,
                    audio_end=cp_abs,
                ))
            prev_abs = cp_abs
        # 末尾
        if seg.audio_end > prev_abs:
            sub_segs.append(SpeechSegment(
                start_sample=prev_abs,
                end_sample=seg.audio_end,
                audio_ref=seg.audio_ref,
                audio_start=prev_abs,
                audio_end=seg.audio_end,
            ))

        # 合并过短片段（只更新偏移量，不复制音频）
        MIN_SUB_SAMPLES = int(0.2 * sr)
        result: List[SpeechSegment] = []
        i = 0
        while i < len(sub_segs):
            cur = sub_segs[i]
            if (cur.audio_end - cur.audio_start) >= MIN_SUB_SAMPLES:
                result.append(cur)
                i += 1
            else:
                if result:
                    p = result[-1]
                    merged = SpeechSegment(
                        start_sample=p.start_sample,
                        end_sample=cur.end_sample,
                        audio_ref=p.audio_ref,
                        audio_start=p.audio_start,
                        audio_end=cur.audio_end,
                    )
                    result[-1] = merged
                    i += 1
                else:
                    merged = cur
                    j = i + 1
                    while j < len(sub_segs) and (merged.audio_end - merged.audio_start) < MIN_SUB_SAMPLES:
                        nxt = sub_segs[j]
                        merged = SpeechSegment(
                            start_sample=merged.start_sample,
                            end_sample=nxt.end_sample,
                            audio_ref=merged.audio_ref,
                            audio_start=merged.audio_start,
                            audio_end=nxt.audio_end,
                        )
                        j += 1
                    result.append(merged)
                    i = j

        return result if result else [seg]

    def _match_speaker(
        self, seg: SpeechSegment,
        emb_cache: Dict[Tuple[int, int], np.ndarray]
    ) -> Tuple[str, float, List[str], np.ndarray]:
        """
        对一个片段匹配说话人：提取embedding，与注册声纹库逐一打分。
        优先使用 emb_cache 中已缓存的 embedding（避免重复调用 CAM++）。
        返回 (top1_id, top1_score, top5_ids, embedding)。
        top5_ids 用于 _merge_speech_segments 中的投票合并。
        """
        extractor = self._enhanced_engine.extractor
        emb = self._get_cached_emb(seg.audio_start, seg.audio_end, emb_cache,
                                   seg.audio_ref, extractor)

        # 与注册声纹库逐一打分
        scored: List[Tuple[str, float]] = []
        for sid, reg_emb in self._registered_embeddings.items():
            score = self._enhanced_engine._cosine_sim(emb, reg_emb)
            scored.append((sid, float(score)))

        if not scored:
            return "unknown", 0.0, ["unknown"], emb

        scored.sort(key=lambda x: x[1], reverse=True)
        top1_id, top1_score = scored[0]
        top5_ids = [sid for sid, _ in scored[:5]]

        return top1_id, top1_score, top5_ids, emb

    # ================================================================
    # Step 3: ASR 转录
    # ================================================================

    async def _transcribe_segments(
        self,
        labeled_segments: List[Tuple[SpeechSegment, str, float, List[str], np.ndarray, int]],
    ) -> List[TurnSegment]:
        """对每个切片片段进行 ASR 转录"""
        results: List[TurnSegment] = []
        total = len(labeled_segments)

        for i, item in enumerate(labeled_segments):
            # item 是 6 元组: (seg, speaker_id, confidence, top5_ids, emb, merged_from)
            if i % 20 == 0:
                print(f"[Pipeline2-ASR] 转录 {i+1}/{total}...", flush=True)
            seg, speaker_id, confidence, top5_ids, _, merged_from = item
            self._report_progress("ASR转录", i / total)

            try:
                # ASR 推理（同步，在线程池中运行），输入为 float32（与实时模式一致）
                loop = asyncio.get_event_loop()
                text = await loop.run_in_executor(
                    None,
                    self._asr_inference,
                    seg.audio,
                )

                if not text or not text.strip():
                    # ASR 空文本也保留该片段，不能因为没有文字就跳过
                    text = ""

                # 标点后处理
                if self._punc_model is not None and text:
                    try:
                        loop2 = asyncio.get_event_loop()
                        text = await loop2.run_in_executor(
                            None,
                            self._punc_inference,
                            text,
                        )
                    except Exception:
                        pass

                # ASR 后置过滤：丢弃无意义片段
                # 策略1：已知无意义词（仅语气词/叹词）
                # 策略2：中文有效字符占比 < 30% 且字数极少（大量ASR乱码）
                text_stripped = (text.strip() if text else "").replace(' ', '')
                if text_stripped:
                    chinese_only = ''.join(c for c in text_stripped if '\u4e00' <= c <= '\u9fff')
                    chinese_chars = len(chinese_only)
                    total_chars = len(text_stripped)
                    valid_ratio = chinese_chars / total_chars if total_chars > 0 else 0

                    is_meaningless = (
                        chinese_only in _MEANINGLESS_PATTERNS or
                        (valid_ratio < 0.3 and chinese_chars < 3)
                    )

                    if is_meaningless:
                        print(f"  ASR[{i+1}] 过滤无意义片段: \"{text_stripped}\"", flush=True)
                        continue
                else:
                    # 空文本直接跳过，不保留无意义的空片段
                    print(f"  ASR[{i+1}] 空文本，跳过", flush=True)
                    continue

                results.append(TurnSegment(
                    speaker_id=speaker_id,
                    speaker_name=self._speaker_names.get(speaker_id),
                    text=text.strip() if text else "",
                    start_ms=seg.start_ms,
                    end_ms=seg.end_ms,
                    confidence=confidence,
                    top3_ids=top5_ids[:3],
                    merged_from=merged_from,
                ))

            except Exception as e:
                print(f"  ASR[{i+1}] 失败: {e}", flush=True)

        return results

    def _asr_inference(self, audio_data: np.ndarray) -> str:
        """同步 ASR 推理"""
        with torch.no_grad():
            result = self._asr_model.generate(
                input=audio_data,
                language=self.language,
            )

        if result and len(result) > 0:
            return result[0].get("text", "")
        return ""

    def _punc_inference(self, text: str) -> str:
        """同步标点推理"""
        if not text.strip():
            return text

        text_tensor = torch.tensor([ord(c) for c in text], dtype=torch.long).unsqueeze(0)

        with torch.no_grad():
            result = self._punc_model(text_tensor)

        if result and len(result) > 0:
            return result[0].get("text", text)
        return text

    # ================================================================
    # Step 4: 组装 turns
    # ================================================================

    def _build_turns(self, segments: List[TurnSegment]) -> List[TurnSegment]:
        """
        组装 turns：纯文本拼接，top-5投票合并已在 _merge_speech_segments 中完成。
        相邻片段 speaker_id 相等 且 gap < 5s → 拼接文本。
        """
        if not segments:
            return []

        segments = sorted(segments, key=lambda s: s.start_ms)

        merged: List[TurnSegment] = []
        cur = TurnSegment(
            speaker_id=segments[0].speaker_id,
            speaker_name=segments[0].speaker_name,
            text=segments[0].text,
            words=list(segments[0].words),
            start_ms=segments[0].start_ms,
            end_ms=segments[0].end_ms,
            confidence=segments[0].confidence,
            top3_ids=list(segments[0].top3_ids),
            merged_from=segments[0].merged_from,
        )

        for i in range(1, len(segments)):
            nxt = segments[i]
            gap = nxt.start_ms - cur.end_ms

            if cur.speaker_id == nxt.speaker_id and gap < 5000:
                cur.text = cur.text + " " + nxt.text
                cur.end_ms = nxt.end_ms
                cur.confidence = max(cur.confidence, nxt.confidence)
                cur.merged_from += nxt.merged_from
            else:
                merged.append(cur)
                cur = TurnSegment(
                    speaker_id=nxt.speaker_id,
                    speaker_name=nxt.speaker_name,
                    text=nxt.text,
                    words=list(nxt.words),
                    start_ms=nxt.start_ms,
                    end_ms=nxt.end_ms,
                    confidence=nxt.confidence,
                    top3_ids=list(nxt.top3_ids),
                    merged_from=nxt.merged_from,
                )

        merged.append(cur)
        return merged

    def _collect_speakers(self, turns: List[TurnSegment]) -> Dict[str, Dict]:
        """统计说话人"""
        stats: Dict[str, Dict] = {}
        for t in turns:
            sid = t.speaker_id or "unknown"
            if sid not in stats:
                stats[sid] = {
                    "name": t.speaker_name,
                    "count": 0,
                    "total_duration_ms": 0,
                }
            stats[sid]["count"] += 1
            stats[sid]["total_duration_ms"] += t.end_ms - t.start_ms
        return stats

    # ================================================================
    # Step 5: 摘要
    # ================================================================

    async def _generate_summary(self, turns: List[TurnSegment]) -> Dict:
        """生成摘要"""
        if not turns:
            return {}

        transcript_lines = []
        for t in turns:
            label = t.speaker_name if t.speaker_name else (t.speaker_id or "unknown")
            transcript_lines.append({"speaker": label, "text": t.text})

        try:
            from app.services.summary_service import SummaryService
            service = SummaryService()

            def _call():
                return service._call_meetingsummary_from_lines(
                    transcript_lines,
                    prefix=f"final2_{self.meeting_id[:8]}",
                    subdir="final",
                )

            result = await asyncio.to_thread(_call)
            if result:
                return {
                    "overview": (result.get("bullet_points", ["摘要生成失败"])[0]
                                 if result.get("bullet_points") else "无法生成摘要"),
                    "key_decisions": result.get("key_decisions", []),
                    "action_items": result.get("action_items", []),
                }
        except Exception as e:
            print(f"[Pipeline2] 摘要失败: {e}", flush=True)

        return {}


# ================================================================
# 便捷入口
# ================================================================

async def process_audio_offline2(
    meeting_id: str,
    audio_data: np.ndarray,
    sample_rate: int = 16000,
    language: str = "zh",
    on_progress: Optional[Callable[[str, float], None]] = None,
) -> ProcessingResult:
    """离线模式2处理入口"""
    pipeline = OfflinePipeline2(
        meeting_id=meeting_id,
        sample_rate=sample_rate,
        language=language,
        on_progress=on_progress,
    )
    return await pipeline.process(audio_data)
